Larppture Weapons — Dark 2D Resource Pack
Minecraft Java 1.21.11

Оружие:
- mace — кровавая тёмно-красная булава
- scythe — тёмная мрачная коса

Это именно 2D-ресурс-пак: оружие отображается как обычная Minecraft item-иконка,
без 3D JSON-геометрии.

Привязка:
Плагин использует item_model:
  larppture:mace
  larppture:scythe

Установка:
1. Положите ZIP в папку resourcepacks клиента или настройте его как server resource pack.
2. Используйте версию плагина с item_model, которую мы подготовили ранее.
3. В игре перезагрузите ресурсы клавишами F3+T.

Если нужно заменить стиль, достаточно заменить:
assets/larppture/textures/item/mace.png
assets/larppture/textures/item/scythe.png


Обновление: исправлены трансформации удержания косы и булавы в первой/третьей персоне — теперь они ориентированы как оружие.


Элитра:
- larppture:elytra — кастомная иконка элитры
- assets/minecraft/textures/entity/elytra.png — текстура элитры на игроке
- F — Super Dash (логика способности находится в плагине)


Золотой трезубец:
- larppture:golden_trident — текстура из golden_trident.png
- Использует vanilla minecraft:item/trident как родительскую модель, поэтому в руках сохраняется стандартная анимация/ориентация трезубца.
- Плагин Larppture Weapons должен задавать item_model: larppture:golden_trident.
